import { pool } from "./pool.js";

function sanitize(s: string | null | undefined): string | null {
  if (!s) return s;
  return s.replace(/\x00/g, "").trim();
}

export async function seed() {
  const { modules } = await import("../../data/modules/index");
  const client = await pool.connect();
  try {
    await client.query("BEGIN");

    let totalChapters = 0;
    let totalSideMenus = 0;
    let totalLessons = 0;

    for (let mi = 0; mi < modules.length; mi++) {
      const mod = modules[mi];
      const chNum = mi + 1;

      const chResult = await client.query(
        `INSERT INTO chapters (chapter_number, title_en, title_bn, level, is_published, sort_order)
         VALUES ($1, $2, $3, $4, true, $5)
         ON CONFLICT (chapter_number) DO UPDATE SET
           title_en = EXCLUDED.title_en,
           title_bn = EXCLUDED.title_bn,
           level = EXCLUDED.level
         RETURNING id`,
        [chNum, mod.title, mod.titleBn || null, mod.level || "Beginner", chNum],
      );
      const chapterId = chResult.rows[0].id;
      totalChapters++;

      const smResult = await client.query(
        `INSERT INTO side_menus (chapter_id, label_en, label_bn, sort_order, is_active)
         VALUES ($1, $2, $3, 1, true)
         ON CONFLICT DO NOTHING
         RETURNING id`,
        [chapterId, mod.title, mod.titleBn || null],
      );
      let sideMenuId = smResult.rows[0]?.id;
      if (!sideMenuId) {
        const existing = await client.query(
          "SELECT id FROM side_menus WHERE chapter_id = $1 LIMIT 1",
          [chapterId],
        );
        sideMenuId = existing.rows[0].id;
      }
      totalSideMenus++;

      for (let li = 0; li < mod.lessons.length; li++) {
        const lesson = mod.lessons[li];
        const lessonNum = li + 1;

        await client.query(
          `INSERT INTO lessons (side_menu_id, lesson_number, title_en, title_bn, content_en, content_bn, code_en, code_bn, takeaways_en, takeaways_bn, level, is_published)
           VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, true)
           ON CONFLICT DO NOTHING`,
          [
            sideMenuId,
            lessonNum,
            sanitize(lesson.title),
            sanitize(lesson.titleBn),
            sanitize(lesson.content) || "",
            sanitize(lesson.contentBn),
            sanitize(lesson.code),
            sanitize(lesson.codeBn),
            (lesson.takeaways || []).map((t: string) => sanitize(t)),
            (lesson.takeawaysBn || []).map((t: string) => sanitize(t)),
            lesson.level || mod.level,
          ],
        );
        totalLessons++;
      }
      console.log(`  ✔ ${mod.title}: ${mod.lessons.length} lessons`);
    }

    await client.query("COMMIT");
    console.log(`✔ ${totalChapters} chapters created`);
    console.log(`✔ ${totalSideMenus} side menus created`);
    console.log(`✔ ${totalLessons} lessons created`);
    console.log("\n✅ Seed complete!");
  } catch (err) {
    await client.query("ROLLBACK");
    console.error("Seed failed:", err);
    throw err;
  } finally {
    client.release();
  }
}

// CLI: node dist/db/seed.js
if (require.main === module) {
  seed().then(() => {
    pool.end();
    process.exit(0);
  }).catch(() => {
    pool.end();
    process.exit(1);
  });
}
